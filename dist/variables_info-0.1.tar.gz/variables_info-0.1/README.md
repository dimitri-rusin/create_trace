# Info

Print info about the content of variables. Use conveniently by writing the name of the variable.
